# Letter Otomasyonu Patch Pack (v6) — Yapılanlar ve Beklenenler

Bu dosya, bu çalışmanın **ilk promptundan son promptuna kadar** yapılan geliştirmelerin **uçtan uca** özetidir.
Amaç: **Ödeme mektubu taleplerinin otomatikleştirilmesi**, mevcut manuel akış korunurken **performans, idempotency, gözlemlenebilirlik** ve **operasyonel güvenilirliğin** artırılması.

---

## 0) Problemin kısa özeti

Mevcut akış:
1) UI kullanıcı eventi → `tletter_request` + `tletter_item`
2) `jobs_letterProcessingJob` READY request’leri pick eder, PDF üretir, e-posta gönderir, status günceller.

İstenen:
- UI olmadan **otomatik talep üretimi** (günde 3–4 run, ilk run 06:00, günlük ~1000 kayıt)
- İş kuralı: **eft.kasTarih = 17** olanlar için **18 sabah 06:00**’da talep üretimi
- Aynı provizyon için manuel/otomatik **çakışma olmasın** (hangisi önce başarılıysa diğeri üretmesin)
- Processing job için **parallel-safe** pick (READY→PROCESSING atomic, SKIP LOCKED)
- Gün sonu (17:35) **başarısız otomatik talepler** için **detaylı mail** (request+item+attempt)

Kısıt:
- Letter tablolarına **yeni alan eklemeden** manuel/otomatik ayrımı yapılmalı.

---

## 1) Yapılanlar (tam liste)

### A) Otomatik talep oluşturma (Auto Job)
- Yeni job: `jobs_autoOdemeMektubuTalepOlusturmaJob`
- Yeni servis: `AutoOdemeMektubuTalepService`
- Çalışma günü ve catch-up hesabı:
  - **Cumartesi + Pazar** ve **resmi tatillerde** job **çalışmaz (skip)**.
  - Bir sonraki iş günü çalıştığında, **kaçırılan tüm günleri** yakalar:  

  - Catch-up başlangıcı, sadece "tamamlandı" sayılan AUTO request'lerden hesaplanır (daha sağlam):
    - Dahil edilen request status'leri: **SENT(6)**, **PARTIAL_SENT(5)**, **NO_ITEMS(10)**, **VALIDATION_FAIL(2)**
    - **FAILED/ALL_FAILED** dahil edilmez; böylece sonraki iş gününde tekrar deneme şansı korunur.
    `startKasDate = (son AUTO kasDate + 1)`, `endKasDate = today - 1`
  - İlk çalıştırmada en azından dünkü gün işlenir.
  - Örnek: Pazartesi iş günü ise `endKasDate=Pazar`, `startKasDate` son işlendiye göre ayarlanır (hafta sonu günleri dahil catch-up).
- Veri çekimi:
  - Yeni query metodu beklentisi: `getBorcaYapilmisOdemeListByKasTarih(...)` (**eft.kasTarih between**)
- Talep üretimi:
  - `max-items-per-request=1000` chunk
  - Request önce **PENDING**, item insert bitince **READY**
- Request idempotency:
  - `scope_value = AUTO_ODEME|KAS=<date>|BRANCH=<id>|PART=<n>`
  - Aynı scope varsa aynı gün tekrar request açılmaz
- Item-level dedupe:
  - `receiver_key = provizyonId`
  - Daha önce **SENT** olmuş provizyonlar çıkarılır (kalıcı dedupe)
  - Başka request pipeline’ında olanlar çıkarılır (geçici dedupe)
- Log/metric:
  - fetched/uniq/skipSucc/skipPipe/willInsert/reqCreated/itemInserted
  - requeue sayaçları (aşağıda)

### B) Manuel akış iyileştirmesi (dedupe + NO_ITEMS)
- Manuel request oluştururken de aynı dedupe kuralı uygulanabilir:
  - SENT/pipeline provizyonlar item olarak tekrar basılmaz
- Dedupe sonrası receiver listesi boş kalırsa:
  - request **NO_ITEMS** durumuna alınabilir
  - UI tarafında gösterilebilecek `NoItemsAfterDedupeException` ile kısa kullanıcı mesajı üretilebilir

### C) Processing Job — READY→PROCESSING atomic claim (PG SKIP LOCKED)
- PostgreSQL için atomic claim eklendi:
  - `FOR UPDATE SKIP LOCKED` + `LIMIT`
  - aynı SQL içinde `UPDATE … RETURNING`
- Repository custom:
  - `LetterRequestRepositoryCustom#claimReadyRequests(limit, updater, requestTypeId, branchId)`
- Bu sayede:
  - paralel worker/instance olsa bile aynı request iki kez pick edilmez
  - pick+update tek roundtrip

### D) Item-level atomic claim (opsiyonel paralel item işleme)
- `LetterItemRepositoryCustom`:
  - `claimReadyItemsForRequest(requestId, limit, updater)`
  - `claimReadyItemsForProcessingRequests(limit, updater, requestTypeId, branchId)`
- `FOR UPDATE SKIP LOCKED` ile item çakışması engellenir (aynı item iki işleyicide aynı anda işlenmez)

### E) İş günü / resmi tatil takvimi
- `BusinessCalendarService`
- `HolidayProvider`:
  - DB tabanlı (`DbHolidayProvider` + `HolidayRepository`) veya
  - config tabanlı (`ConfigHolidayProvider` + `holiday.dates=...`)
- Kural:
  - ✅ Cumartesi ve Pazar tatilnü
  - ❌ Pazar iş günü değil
  - ❌ Resmi tatiller iş günü değil

### F) Smarter Requeue (aynı gün FAIL olmuş auto request)
- Amaç: aynı scope için DB’de request şişmesini önlemek + aynı gün içinde otomatik retry
- Kural:
  - Aynı scope request bulunursa **yeni request açılmaz**
  - Status FAILED/ALL_FAILED ise:
    - sadece **aynı gün oluşturulmuş** request için requeue (config: `auto.odeme.requeue.same-day-only=true`)
    - sadece retryable item’lar resetlenir:
      - `FAILED item` ve `attempt_count < maxAttempt` → tekrar READY
      - `attempt_count >= maxAttempt` item’lar resetlenmez (skip)
    - retryable item yoksa request READY’ye çekilmez
- Sayaçlar:
  - `requeuedReq`, `requeuedItems`, `requeueSkipNotSameDay`, `requeueSkipMaxAttempt`, `requeueNoRetryable`

### G) 17:35 Gün sonu başarısız otomatik talepler maili
- Job: `jobs_dailyLetterFailureDetailMailJob`
- Yalnızca **bugün oluşturulan** (`created_at` bugün aralığında) ve **created_by=SYSTEM_AUTO_JOB** request’leri toplar
- Branch bazlı mail:
  - `BranchMailResolver` ile şube maili (varsa), yoksa `ogmfon@tcmb.gov.tr`
- İçerik:
  - request + item + attempt detayları HTML tablo

### H) Performans indeksleri
- `sql/letter_performance_indexes.sql` içinde:
  - `tletter_request(status_id, created_at)` (+ next_attempt_at opsiyonel)
  - `tletter_item(request_id)` + `tletter_item(receiver_key)`
  - `tletter_attempt(request_id, created_at desc)` + `tletter_attempt(item_id, created_at desc)`
- Opsiyonel: auto scope partial unique index (DB tarafı)

---

## 2) Beklenenler (Acceptance / Test Checklist)

### Auto Job — çalışma günü ve hedef gün
- [ ] Job **Pazar** çalışsa bile `shouldRunToday=false` ile **iş üretmez**
- [ ] Job **Cumartesi ve Pazar tatilnormal çalışır
- [ ] Resmi tatilde job **iş üretmez**
- [ ] 18 06:00 run → `targetKasDate=17` (17 tatilse 16, vs.)
- [ ] Sorgu **eft.kasTarih** aralığına göre yapılır: `[kasDate 00:00, kasDate+1 00:00)`

### Auto Job — idempotency ve dedupe
- [ ] Aynı gün 06:00, 10:00, 14:00, 17:00 çalışsa bile aynı scope için **request tekrar açılmaz**
- [ ] Daha önce **SENT** olmuş provizyonlar hiçbir koşulda tekrar item’a girmez (manuel/otomatik)
- [ ] Pipeline’da olan provizyonlar (PENDING/READY/PROCESSING/PARTIAL/SENT) tekrar item’a girmez
- [ ] ReceiverKey uniqueness: aynı provizyon aynı request içinde tek item olur

### Auto Job — request oluşturma ve status sırası
- [ ] Request önce PENDING açılır
- [ ] Item insert tamamlanınca request READY olur
- [ ] READY olmadan processing job pick etmez

### Smarter Requeue
- [ ] Aynı scope request FAILED/ALL_FAILED ise ve **created_at bugün** ise:
  - [ ] `attempt_count < max` olan FAILED item’lar READY’ye resetlenir
  - [ ] resetlenen item varsa request READY’ye çekilir
- [ ] `attempt_count >= max` item’lar resetlenmez ve “skipMaxAttempt” sayacı artar
- [ ] Retryable item yoksa request READY’ye çekilmez (noRetryable)
- [ ] Aynı scope request FAILED ama **created_at bugün değil** ise requeue yapılmaz (skipNotSameDay)

### Processing Job — atomic claim
- [ ] İki farklı worker aynı anda çalışsa bile **aynı request iki kez PROCESSING’e çekilmez**
- [ ] Claim query’de `requestTypeId/branchId` filtreleri çalışır
- [ ] Claim işlemi kısa transaction, request processing ayrı transaction’da yapılır

### Item-level claim (opsiyonel)
- [ ] Aynı request içinde iki worker çalışsa bile aynı item iki kez claim edilmez (SKIP LOCKED)

### Gün sonu mail
- [ ] 17:35’te yalnızca bugün oluşturulan auto failed request’ler raporlanır
- [ ] Mail body: request + item + attempt detaylarını içerir
- [ ] Alıcı: branch mail varsa oraya, yoksa `ogmfon@tcmb.gov.tr`

### Manuel NO_ITEMS
- [ ] Manuel talepte dedupe sonrası receivers boşsa:
  - [ ] request NO_ITEMS’a çekilebilir
  - [ ] UI’ya “zaten oluşturulmuş/işleniyor” benzeri kısa mesaj döner

---

## 3) Konfigürasyon (varsayılanlar)
`src/main/resources/application-letter-patch.properties`:
- `holiday.provider=db|config`
- `holiday.dates=...`
- `auto.odeme.max-items-per-request=1000`
- `auto.odeme.in-clause-chunk=500`
- `auto.odeme.requeue.same-day-only=true`
- `auto.odeme.requeue.max-attempt-count=3`

---

## 4) Entegrasyon notları
- Patch pack “drop-in” değildir; proje içindeki gerçek enum/status kodlarına göre:
  - READY/PENDING/PROCESSING/FAILED/ALL_FAILED/NO_ITEMS
  - item READY/FAILED/SENT
  kodları uyarlanmalıdır.
- `getBorcaYapilmisOdemeListByKasTarih` metodu eklenmelidir (criteria’da `eft.kasTarih between`).

---

## 5) Rollback / güvenlik
- Yeni custom claim metotları eski pick mantığı yerine geçer; sorun olursa eski metoda dönmek kolaydır.
- Auto job `auto.odeme.enabled=false` ile tamamen kapatılabilir.
- Failure mail job cron’dan çıkarılarak kapatılabilir.

---

## 6) Dosya/patch içeriği
Bu zip içinde:
- Atomic claim repository implementasyonları (request+item)
- Auto job + dedupe + smarter requeue
- Business calendar + holiday providers
- Failure mail job + HTML composer
- SQL index scriptleri
- Bu tek doküman (DELIVERABLE.md)

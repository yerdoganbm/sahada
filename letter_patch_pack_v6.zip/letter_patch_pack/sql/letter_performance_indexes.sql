-- ================================
-- Letter automation - performance & idempotency indexes
-- PostgreSQL
-- Schema: ogmdfifodm
-- ================================

-- Request pick performance (READY -> PROCESSING)
create index if not exists ix_tletter_request_ready_pick
on ogmdfifodm.tletter_request(status_id, created_at);

create index if not exists ix_tletter_request_ready_due
on ogmdfifodm.tletter_request(status_id, next_attempt_at, created_at);

-- Item lookup
create index if not exists ix_tletter_item_request
on ogmdfifodm.tletter_item(request_id);

create index if not exists ix_tletter_item_receiver
on ogmdfifodm.tletter_item(receiver_key);

-- Attempt lookup
create index if not exists ix_tletter_attempt_request
on ogmdfifodm.tletter_attempt(request_id, created_at desc);

create index if not exists ix_tletter_attempt_item
on ogmdfifodm.tletter_attempt(item_id, created_at desc);

-- Auto request key idempotency (optional but recommended)
create unique index if not exists ux_tletter_request_auto_scope
on ogmdfifodm.tletter_request(scope_value)
where created_by = 'SYSTEM_AUTO_JOB' and scope_value is not null;

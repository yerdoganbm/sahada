# Patch Snippets (manuel + auto + query)

## A) Manual insertLetterItem dedupe
Manuel request oluştururken receiver listesi çıktıktan sonra şu iki sorgu ile filtreleyin:
- `findSucceededReceiverKeys(...)`
- `findInPipelineReceiverKeys(...)`

Örnek (receiver_key=provizyonId):
```java
final int CHUNK = 500;
List<String> allKeys = new ArrayList<>(receivers.keySet());

Set<String> succeeded = new HashSet<>();
Set<String> inPipe = new HashSet<>();

for (int i = 0; i < allKeys.size(); i += CHUNK) {
  List<String> chunk = allKeys.subList(i, Math.min(i + CHUNK, allKeys.size()));
  succeeded.addAll(letterItemRepository.findSucceededReceiverKeys((short)1, branchId, chunk));
  inPipe.addAll(letterItemRepository.findInPipelineReceiverKeys((short)1, branchId, chunk));
}

succeeded.forEach(receivers::remove);
inPipe.forEach(receivers::remove);
```

## B) YapilmisOdemelerQueryService kasTarih metodu
Yeni interface metodu:
```java
List<YapilmisOdemeDTO> getBorcaYapilmisOdemeListByKasTarih(String tckn,
                                                          String vkn,
                                                          String kaynakKasSorguNo,
                                                          String kararNo,
                                                          Date kasBaslangicTarih,
                                                          Date kasBitisTarih,
                                                          KararTipiEnum belgeTip,
                                                          Integer belgeNo,
                                                          Integer belgeYil,
                                                          String subeId);
```

Impl’de:
- `cb.between(eft.get("kasTarih"), kasBaslangicTarih, kasBitisTarih)`
- `provizyon.odemeTarih between` kaldırılmalı.

## C) Auto job request oluşturma (PENDING -> item insert -> READY)
- Request ilk açılırken `status=PENDING`
- Items batch insert
- Request `status=READY`

Bu sayede processing job item’lar oluşmadan request’i yakalayamaz.

## D) Otomatik job requestKey
`scope_value` önerisi:
- `AUTO_ODEME|KAS=2026-03-17|BRANCH=34|PART=1`

DB’de optional unique index:
```sql
create unique index if not exists ux_tletter_request_auto_scope
on ogmdfifodm.tletter_request(scope_value)
where created_by = 'SYSTEM_AUTO_JOB' and scope_value is not null;
```

## E) Processing job atomic claim
Bu patch pack içindeki `LetterRequestRepositoryCustom` ve impl ile:
- `FOR UPDATE SKIP LOCKED`
- `UPDATE ... RETURNING`

Tek round-trip ve paralel worker uyumu sağlanır.

## F) Item-level SKIP LOCKED
Bu patch pack içindeki `LetterItemRepositoryCustom` ile:
- item READY(1) -> PROCESSING(4)

Bir request üzerinde birden fazla worker paralel item tüketebilir.


## G) Manuel akışta dedupe sonrası NO_ITEMS mesajı
Dedupe sonrası `receivers` boş kaldıysa:
1) request'i `NO_ITEMS` durumuna çek
2) UI'ya kısa mesaj dön

Önerilen helper: `ManualNoItemsSupport`
```java
if (receivers.isEmpty()) {
  String msg = manualNoItemsSupport.buildUserMessage(succeeded.size(), inPipe.size());
  manualNoItemsSupport.markRequestNoItems(requestId, currentUser, msg);
  throw new NoItemsAfterDedupeException(msg, "Manual request has no items after dedupe. requestId=" + requestId);
}
```

## H) Auto job requeue policy (ALL_FAILED/FAILED)
Aynı gün aynı `scope_value` ile açılmış auto request `FAILED/ALL_FAILED` ise:
- yeni request açılmaz
- aynı request `READY` yapılır
- FAILED item'lar tekrar READY item'a çekilir

Bu patch pack'te `LetterDedupeDao.requeueFailedAutoRequest(...)` bunu yapar.

# Letter Automation Enhancement Pack (Manual + Auto)

Bu paket; mevcut “Letter Request → Letter Item → Processing Job → PDF + Mail” akışını bozmadan, **ödemeye ilişkin mektup taleplerini otomatikleştirmek** ve eş zamanlı çalışan job’larda **tekrar talep/tekrar gönderim riskini sıfırlamak** için hazırlanmıştır.

## 1) Mevcut akış (korunuyor)
1. UI / Kullanıcı event’i: `tletter_request` kaydı oluşur.
2. Request’e bağlı `tletter_item` kayıtları oluşur.
3. `jobs_letterProcessingJob` (veya benzeri) READY talepleri pick’ler:
   - item’lar üzerinde PDF üretir
   - mail gönderir
   - item status + request final status günceller.

## 2) Yeni hedef
- Ödeme mektupları için `tletter_request` + `tletter_item` üretimi **kullanıcıya bağlı olmadan** otomatik yapılacak.
- Otomatik job **günde 3–4 kez** çalışsa bile **aynı provizyon** için tekrar talep üretmeyecek.
- Manuel ve otomatik talepler **kolon eklemeden** ayrılacak.
- Akşam 17:35’te başarısız taleplerin detay maili otomatik atılacak.

## 3) Kritik iş kuralı: kasTarih
- `eft.kasTarihi = 17` olan kayıtlar için;
  - `18 sabah 06:00` itibarıyla otomatik talep oluşturma başlar.
- Tatil günleri (resmi tatiller + pazar) iş günü değildir.
- Cumartesi **iş günüdür**.

Bu nedenle otomatik job, “bugün 06:00” koşusunda **hedef kas günü** olarak `previousBusinessDay(today)` hesaplar.

## 4) Idempotency & dedupe (manuel + otomatik çakışması dahil)
### 4.1 Request-level idempotency
- Otomatik job her request’e deterministik `scope_value` yazar:
  - `AUTO_ODEME|KAS=YYYY-MM-DD|BRANCH=XX|PART=N`
- Aynı scope_value ile request zaten varsa tekrar oluşturmaz.
- DB tarafında (opsiyonel ama önerilir) partial unique index:
  - `ux_tletter_request_auto_scope`

### 4.2 Item-level dedupe
- `receiver_key = provizyonId` varsayımıyla;
- Aynı provizyon daha önce **SENT** olduysa bir daha talep üretilmez.
- Başka bir request tarafından **pipeline**’a alınmışsa (PENDING/READY/PROCESSING/…) yine üretilmez; sonraki run’da tekrar denenebilir.

### 4.3 Manuel vs Otomatik
- Ayrım: `created_by`
  - Otomatik: `SYSTEM_AUTO_JOB`
  - Manuel: kullanıcı
- Dedupe sorguları manuel item insert öncesinde de uygulanır: “hangisi önce başarılı olduysa diğeri artık üretmesin”.

## 5) Parallel-safe processing: SKIP LOCKED
### 5.1 Request claim
- READY → PROCESSING atomic claim:
  - `FOR UPDATE SKIP LOCKED` + `UPDATE … RETURNING`

### 5.2 Item claim
- Item READY → PROCESSING atomic claim:
  - Aynı request üzerinde birden fazla worker paralel çalışabilir.

## 6) Failure mail (17:35)
- Otomatik talepler içinde başarısız olanlar;
  - request + item + attempt detaylarıyla
  - şube yazışma mailine (yoksa `ogmfon@tcmb.gov.tr`) gönderilir.

## 7) Performans
- Pick/Join sorguları için index script’i `sql/letter_performance_indexes.sql` içinde.


## Ek iyileştirmeler (patch pack v2)
- **Auto requeue:** aynı gün aynı `scope_value` ile açılmış auto request `FAILED/ALL_FAILED` ise yeni request açılmaz; request `READY` yapılır ve FAILED item'lar tekrar denemeye alınır.
- **Manual NO_ITEMS:** manuel talepte dedupe sonrası item kalmadıysa request `NO_ITEMS` yapılır ve UI'ya kısa mesaj dönebilecek exception/helper eklenir.

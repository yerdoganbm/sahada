# Integration Steps (Copy/Paste)

> Bu patch pack, sizin projeye **merge edilecek** şekilde hazırlanmıştır.
> Mevcut projeyi 7z’den açamadığım için tüm projeyi yeniden zipleyip “full” olarak ekleyemedim.
> Bu pakette: yeni sınıflar + SQL + entegrasyon adımları + patch snippetleri var.

## 0) Maven/Gradle
Bu sınıflar Spring Boot + Spring Data JPA ile uyumludur.

## 1) Repository wiring
### 1.1 LetterRequestRepository
Mevcut `LetterRequestRepository` interface’inize şu eklemeyi yapın:

```java
public interface LetterRequestRepository extends JpaRepository<LetterRequest, LetterRequestId>, LetterRequestRepositoryCustom {
}
```

### 1.2 LetterItemRepository
Mevcut `LetterItemRepository` interface’inize şu eklemeyi yapın:

```java
public interface LetterItemRepository extends JpaRepository<LetterItem, LetterItemId>, LetterItemRepositoryCustom {
}
```

> Custom impl’ler Spring Data naming ile otomatik bulunur:
> - `LetterRequestRepositoryImpl`
> - `LetterItemRepositoryImpl`

## 2) Processing Job upgrade
Mevcut `jobs_letterProcessingJob` içinde:
1) READY request listesi çektiğiniz kısmı kaldırın.
2) `letterRequestRepository.claimReadyRequests(limit, updater, requestTypeId, branchId)` kullanın.

Alternatif: Bu pakette örnek job var: `jobs_letterProcessingJobV2`.

## 3) Item-level parallelism (opsiyonel)
- Eğer bir request’in item’ları (1000+) uzun sürüyorsa;
  - her request için aynı anda 2-4 worker thread ile `claimReadyItemsForRequest` çağırıp çalıştırabilirsiniz.
  - `LetterItemWorkService` template olarak eklendi.

## 4) Auto job (kasTarih)
### 4.1 Query service
`YapilmisOdemelerQueryService` içine yeni metot:
- `getBorcaYapilmisOdemeListByKasTarih(...)`

`YapilmisOdemelerQueryServiceImpl` içinde:
- `cb.between(eft.get("kasTarih"), kasStart, kasEnd)`
- `provizyon.odemeTarih between` kullanmayın.

### 4.2 Business day logic
Auto job içinde:
- `today` iş günü değilse skip (Pazar/tatil)
- `targetKasDate = previousBusinessDay(today)`

## 5) Failure mail job
- Cron: 17:35
- Job bean: `jobs_dailyLetterFailureDetailMailJob`
- Mail altyapınızdan `MailSenderService` adapter’ı bağlayın.
- Şube mail çözümü:
  - `branch.mail.map=34=a@x,06=b@y`
  - ya da projedeki `SubeKoduEnum` reflection ile çekilir.

## 6) SQL
- `sql/letter_performance_indexes.sql` çalıştırın.

## 7) Config
`src/main/resources` altına (veya mevcut application.properties’e) ekleyin:

```properties
# Holiday provider
holiday.provider=db   # db | config
holiday.dates=2026-01-01,2026-04-23

# Branch mail map (optional)
branch.mail.map=34=dfif34@tcmb.gov.tr

# Processing claim
letter.processing.claim.limit=20
letter.processing.filter.requestTypeId=
letter.processing.filter.branchId=
```


## 8) Manuel NO_ITEMS policy (dedupe sonrası)
Manuel request akışınızda item üretmeden önce dedupe uyguladıktan sonra `receivers` boş kalırsa:
- request'i `NO_ITEMS` status'una çekin (projede hangi kodsa)
- UI'ya kısa bir mesaj gösterin

Bu patch pack'te helper sınıflar eklendi:
- `ManualNoItemsSupport`
- `NoItemsAfterDedupeException`

UI katmanı `NoItemsAfterDedupeException.userMessage` değerini kullanıcıya gösterebilir.

## 9) Auto requeue policy (ALL_FAILED/FAILED)
Aynı gün içinde auto job tekrar koştuğunda:
- aynı `scope_value` zaten varsa **yeni request açmaz**
- eğer mevcut request `FAILED/ALL_FAILED` ise **aynı request'i requeue eder**:
  - request `READY` olur
  - FAILED item'lar tekrar READY item'a çekilir

Bu davranış `AutoOdemeMektubuTalepService` + `LetterDedupeDao.requeueFailedAutoRequest(...)` ile paket içinde vardır.

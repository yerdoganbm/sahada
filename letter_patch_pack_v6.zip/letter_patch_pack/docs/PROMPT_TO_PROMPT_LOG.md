# Prompt → Prompt: Yapılanların Tam Listesi

Bu doküman, bu thread’de ilk talebinden (otomatik ödeme mektubu talep üretimi) son talebine (processing claim + iş günü takvimi + paralellik + raporlama) kadar **tüm geliştirme kararlarını** tek yerde toplar.

## 1) Problem tanımı
- UI’dan alınan ödeme mektubu talebi `tletter_request` tablosuna yazılıyor.
- Ardından bir processing job READY kayıtlarını pickleyip PDF üretiyor ve mail atıyor.
- Hedef: ödeme mektupları için talep üretimini UI’sız otomatik yapmak (günde 3–4 run, max 1000 item).

## 2) Otomatik talep job tasarımı
- Yeni job: “AUTO ödeme mektubu talep oluşturma”.
- Kaynak veri: borca yapılan ödeme listesi (provizyon bazlı).
- Job çıktısı: `tletter_request` + `tletter_item`.

## 3) Kas tarihi kuralı
- `eft.kasTarih = 17` olanlar için `18 sabah 06:00` itibarıyla talep üretilmeye başlanır.
- Bu nedenle query tarafında kasTarih’a göre filtreleyen yeni metot eklenir.

## 4) Idempotency / dedupe
- Request-level: otomatik job deterministik `scope_value` yazar (`AUTO_ODEME|KAS=...|BRANCH=...|PART=...`).
- Item-level: receiver_key=provizyonId ile dedupe:
  - SENT olduysa bir daha üretilmez.
  - Pipeline’da ise üretilmez (sonraki run’da tekrar denenebilir).
- Manuel vs otomatik ayrımı `created_by` ile yapılır (kolon eklemeden).

## 5) Status yarış koşulu düzeltmesi
- Otomatik job request’i PENDING basar.
- Item insert tamamlanınca request READY yapılır.
- Böylece processing job “READY ama item yok” durumuna düşmez.

## 6) Processing job paralel güvenliği
- READY request pick: PostgreSQL `FOR UPDATE SKIP LOCKED` + `UPDATE ... RETURNING` ile atomic claim.
- Parametreli filtre: request_type_id ve branch_id ile worker’ları bölme imkânı.

## 7) Item-level paralellik
- Item READY -> PROCESSING claim de SKIP LOCKED ile yapılır.
- Aynı request üzerinde birden fazla worker item tüketebilir.

## 8) İş günü takvimi
- Cumartesi ve Pazar tatil.
- Pazar hariç.
- Resmi tatiller hariç (DB veya config).

## 9) Gün sonu hata raporu maili
- 17:35’te; otomatik talepler içinde başarısız olanlar için
  - request + item + attempt detayları HTML tablo ile mail atılır.
  - alıcı: şube yazışma maili (yoksa ogmfon@tcmb.gov.tr).

## 10) Performans
- Request pick, item lookup ve attempt lookup için index scriptleri.


## 11) Auto requeue policy
- Aynı gün aynı scope_value ile açılan auto request ALL_FAILED/FAILED ise yeni request açılmadan requeue edilir.
- Request READY yapılır, FAILED item’lar tekrar READY item’a çekilir.

## 12) Manual NO_ITEMS policy
- Manuel talep akışında dedupe sonrası item kalmazsa request NO_ITEMS yapılır.
- UI katmanına kısa mesaj göstermek için exception/helper eklenir.

package tr.gov.tcmb.ogmdfif.service.auto;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tr.gov.tcmb.ogmdfif.model.dto.YapilmisOdemeDTO;
import tr.gov.tcmb.ogmdfif.service.ProvizyonIslemleriService;
import tr.gov.tcmb.ogmdfif.service.YapilmisOdemelerQueryService;
import tr.gov.tcmb.ogmdfif.service.calendar.BusinessValidationCalendarService;
import tr.gov.tcmb.ogmdfif.util.DateUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.OffsetDateTime;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class AutoOdemeMektubuTalepService {

    private final BusinessValidationCalendarService calendarService;
    private final ProvizyonIslemleriService provizyonIslemleriService;
    private final YapilmisOdemelerQueryService odemelerQueryService;
    private final LetterDedupeDao dedupeDao;
    private final LetterItemBatchInsertService itemBatchInsertService;

    @PersistenceContext
    private EntityManager em;

    @Value("${auto.odeme.enabled:true}")
    private boolean enabled;

    @Value("${auto.odeme.max-items-per-request:1000}")
    private int maxItems;

    @Value("${auto.odeme.in-clause-chunk:500}")
    private int inClauseChunk;

    @Value("${auto.odeme.requestTypeId:1}")
    private short requestTypeId;

    @Value("${auto.odeme.scopeId:1}")
    private short scopeId;

    @Value("${auto.odeme.createdBy:SYSTEM_AUTO_JOB}")
    private String createdBy;

    // Smarter requeue
    @Value("${auto.odeme.requeue.enabled:true}")
    private boolean requeueEnabled;

    @Value("${auto.odeme.requeue.same-day-only:true}")
    private boolean requeueSameDayOnly;

    @Value("${auto.odeme.requeue.max-attempt-count:3}")
    private int requeueMaxAttemptCount;

    public void runOnce() {
        if (!enabled) return;

        ZoneId zone = ZoneId.of("Europe/Istanbul");
        LocalDate today = LocalDate.now(zone);

        // Hafta sonu (Cumartesi/Pazar) ve resmi tatillerde job çalışmaz.
        // Bir sonraki iş günü çalıştığında, arada kaçırılan günlerin (kasTarih) tamamını yakalar.
        if (!calendarService.shouldRunToday(today)) {
            log.info("AUTO_ODEME: skip today={}, weekend/holiday", today);
            return;
        }

        // Catch-up: Son başarılı/başarısız denenen AUTO kas tarihinden sonraki günlerden başlayıp düne kadar işle.
        // (Aynı gün içinde job tekrar çalışırsa scope_value + item dedupe tekrar üretmeyi engeller.)
        LocalDate endKasDate = today.minusDays(1);
        if (endKasDate.isBefore(LocalDate.of(2000, 1, 1))) return;

        List<String> branchIds = provizyonIslemleriService.getSubeIdList();

        for (String branchId : branchIds) {
            try {
                LocalDate startKasDate = dedupeDao.findMaxAutoKasDate(branchId, createdBy, requestTypeId, List.of((short)6, (short)5, (short)10, (short)2));
                if (startKasDate != null) {
                    startKasDate = startKasDate.plusDays(1);
                } else {
                    // İlk kez çalışıyorsa en azından dünkü günü hedefle
                    startKasDate = endKasDate;
                }

                if (startKasDate.isAfter(endKasDate)) {
                    log.info("AUTO_ODEME: branch={} nothing-to-catchup startKasDate={} endKasDate={}", branchId, startKasDate, endKasDate);
                    continue;
                }

                LocalDate kasDate = startKasDate;
                while (!kasDate.isAfter(endKasDate)) {
                    Date kasStart = DateUtils.convertToDateFromLocalDate(kasDate);
                    Date kasEnd = DateUtils.convertToDateFromLocalDate(kasDate.plusDays(1)); // [start, nextDay)

                    OffsetDateTime dayStart = today.atStartOfDay(zone).toOffsetDateTime();
                    OffsetDateTime dayEnd = today.plusDays(1).atStartOfDay(zone).toOffsetDateTime();

                    createForBranch(branchId, kasDate, kasStart, kasEnd, dayStart, dayEnd);

                    kasDate = kasDate.plusDays(1);
                }
            } catch (Exception ex) {
                log.error("AUTO_ODEME: branch={} catch-up failed", branchId, ex);
            }
        }
    }

        // “KasTarih=17 olanlar 18 sabah 06:00’da talep olsun”:
        // today=18 => targetKasDate=17 (tatil/pazar ise bir önceki iş gününe kayar)
        LocalDate targetKasDate = calendarService.previousBusinessDay(today);

        OffsetDateTime dayStart = today.atStartOfDay(zone).toOffsetDateTime();
        OffsetDateTime dayEnd = today.plusDays(1).atStartOfDay(zone).toOffsetDateTime();

        Date kasStart = DateUtils.convertToDateFromLocalDate(targetKasDate);
        Date kasEnd = DateUtils.convertToDateFromLocalDate(targetKasDate.plusDays(1)); // [start, nextDay)

        List<String> branchIds = provizyonIslemleriService.getSubeIdList();
        for (String branchId : branchIds) {
            try {
                createForBranch(branchId, targetKasDate, kasStart, kasEnd, dayStart, dayEnd);
            } catch (Exception ex) {
                log.error("AUTO_ODEME: branch={} kasDate={} failed", branchId, targetKasDate, ex);
            }
        }
    }

    @Transactional
    protected void createForBranch(String branchId,
                                   LocalDate kasDate,
                                   Date kasStart,
                                   Date kasEnd,
                                   OffsetDateTime dayStart,
                                   OffsetDateTime dayEnd) {

        // NOTE: Bu metot projede eklenmeli (eft.kasTarih between)
        List<YapilmisOdemeDTO> list = odemelerQueryService.getBorcaYapilmisOdemeListByKasTarih(
                null, null, null, null,
                kasStart, kasEnd,
                null, null, null,
                branchId
        );

        int fetched = list.size();

        // receiver_key = provizyonId (string)
        LinkedHashMap<String, String> receivers = new LinkedHashMap<>();
        for (YapilmisOdemeDTO dto : list) {
            String provId = String.valueOf(dto.getId());
            // value tarafı opsiyonel; item payload üretiminde kullanılabilir
            String receiverValue = safe(dto.getTckn()) + "|" + safe(dto.getVkn());
            receivers.putIfAbsent(provId, receiverValue);
        }

        int uniq = receivers.size();
        if (uniq == 0) {
            log.info("AUTO_ODEME_STATS branch={} kasDate={} fetched=0 uniq=0 ...", branchId, kasDate);
            return;
        }

        // Dedupe (manuel + otomatik ortak kural):
        // - Daha önce SENT olanları kalıcı çıkar
        // - Pipeline’da olanları geçici çıkar
        List<String> allKeys = new ArrayList<>(receivers.keySet());
        Set<String> succeeded = new HashSet<>();
        Set<String> inPipe = new HashSet<>();

        for (int i = 0; i < allKeys.size(); i += inClauseChunk) {
            List<String> chunk = allKeys.subList(i, Math.min(i + inClauseChunk, allKeys.size()));
            succeeded.addAll(dedupeDao.findSucceededReceiverKeys(requestTypeId, branchId, chunk));
            inPipe.addAll(dedupeDao.findInPipelineReceiverKeys(requestTypeId, branchId, chunk));
        }

        succeeded.forEach(receivers::remove);
        inPipe.forEach(receivers::remove);

        int willInsert = receivers.size();

        // 1000’lik parçalara böl
        List<Map<String, String>> parts = chunkMap(receivers, maxItems);

        int createdReq = 0;
        int insertedItems = 0;

        int requeuedReq = 0;
        int requeuedItems = 0;
        int requeueSkipNotSameDay = 0;
        int requeueSkipMaxAttempt = 0;
        int requeueNoRetryable = 0;

        int partNo = 1;
        for (Map<String, String> part : parts) {
            String scopeValue = buildScopeValue(branchId, kasDate, partNo);

            // Scope-based idempotency + smarter requeue policy:
            // - scope_value varsa yeni request açma.
            // - scope_value'a ait request FAILED/ALL_FAILED ise (aynı gün) retryable item varsa requeue et.
            Optional<LetterDedupeDao.AutoRequestInfo> existing = dedupeDao.findAutoRequestInfo(scopeValue);
            if (existing.isPresent()) {
                short st = existing.get().getStatusId();

                if (requeueEnabled && (st == 7 || st == 9)) { // FAILED / ALL_FAILED
                    if (requeueSameDayOnly &&
                            (existing.get().getCreatedAt().isBefore(dayStart) || !existing.get().getCreatedAt().isBefore(dayEnd))) {
                        requeueSkipNotSameDay++;
                    } else {
                        LetterDedupeDao.RequeueResult rr = dedupeDao.requeueFailedAutoRequest(
                                existing.get().getId(),
                                createdBy,
                                requeueMaxAttemptCount,
                                requeueSameDayOnly,
                                dayStart,
                                dayEnd
                        );

                        requeueSkipMaxAttempt += rr.getFailedItemsMaxAttempt();
                        requeuedItems += rr.getRetryableItemsReset();

                        if (rr.isRequestRequeued()) {
                            requeuedReq++;
                        } else if (rr.getRetryableItemsReset() == 0) {
                            requeueNoRetryable++;
                        }
                    }
                }

                partNo++;
                continue;
            }

            UUID requestId = createRequest(branchId, kasDate, scopeValue);
            createdReq++;

            insertedItems += itemBatchInsertService.insertItems(requestId, part);

            // request READY (PENDING -> READY)
            em.createNativeQuery("""
                update ogmdfifodm.tletter_request
                   set status_id = 3,
                       updated_at = now(),
                       updater = :updater
                 where id = :id
            """)
              .setParameter("updater", createdBy)
              .setParameter("id", requestId)
              .executeUpdate();

            partNo++;
        }

        AutoJobRunStats stats = AutoJobRunStats.builder()
                .branchId(branchId)
                .kasDate(String.valueOf(kasDate))
                .fetchedCandidateCount(fetched)
                .uniqueReceiverCount(uniq)
                .skippedSucceededCount(succeeded.size())
                .skippedInPipelineCount(inPipe.size())
                .willInsertCount(willInsert)
                .createdRequestCount(createdReq)
                .insertedItemCount(insertedItems)
                .requeuedRequestCount(requeuedReq)
                .requeuedItemResetCount(requeuedItems)
                .requeueSkippedNotSameDayCount(requeueSkipNotSameDay)
                .requeueSkippedMaxAttemptCount(requeueSkipMaxAttempt)
                .requeueNoRetryableItemsCount(requeueNoRetryable)
                .build();

        log.info("AUTO_ODEME_STATS branch={} kasDate={} fetched={} uniq={} skipSucc={} skipPipe={} willInsert={} reqCreated={} itemInserted={} requeuedReq={} requeuedItems={} requeueSkipNotSameDay={} requeueSkipMaxAttempt={} requeueNoRetryable={}",
                stats.getBranchId(), stats.getKasDate(),
                stats.getFetchedCandidateCount(), stats.getUniqueReceiverCount(),
                stats.getSkippedSucceededCount(), stats.getSkippedInPipelineCount(),
                stats.getWillInsertCount(), stats.getCreatedRequestCount(), stats.getInsertedItemCount(),
                stats.getRequeuedRequestCount(), stats.getRequeuedItemResetCount(),
                stats.getRequeueSkippedNotSameDayCount(), stats.getRequeueSkippedMaxAttemptCount(),
                stats.getRequeueNoRetryableItemsCount());
    }

    private UUID createRequest(String branchId, LocalDate kasDate, String scopeValue) {
        UUID id = UUID.randomUUID();

        // Request ilk PENDING
        // status_id: 1=PENDING varsayımı (sizinki farklıysa update edin)
        em.createNativeQuery("""
            insert into ogmdfifodm.tletter_request
              (id, request_type_id, scope_id, scope_value, first_payment_date, last_payment_date,
               branch_id, status_id, created_by, created_at, updated_at)
            values
              (:id, :requestTypeId, :scopeId, :scopeValue, :d, :d,
               :branchId, 1, :createdBy, now(), now())
        """)
          .setParameter("id", id)
          .setParameter("requestTypeId", requestTypeId)
          .setParameter("scopeId", scopeId)
          .setParameter("scopeValue", scopeValue)
          .setParameter("d", kasDate)
          .setParameter("branchId", branchId)
          .setParameter("createdBy", createdBy)
          .executeUpdate();

        return id;
    }

    private static String buildScopeValue(String branchId, LocalDate kasDate, int partNo) {
        return "AUTO_ODEME|KAS=" + kasDate + "|BRANCH=" + branchId + "|PART=" + partNo;
    }

    private static List<Map<String, String>> chunkMap(Map<String, String> src, int size) {
        List<Map<String, String>> out = new ArrayList<>();
        Map<String, String> cur = new LinkedHashMap<>();
        for (Map.Entry<String, String> e : src.entrySet()) {
            cur.put(e.getKey(), e.getValue());
            if (cur.size() >= size) {
                out.add(cur);
                cur = new LinkedHashMap<>();
            }
        }
        if (!cur.isEmpty()) out.add(cur);
        return out;
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }
}

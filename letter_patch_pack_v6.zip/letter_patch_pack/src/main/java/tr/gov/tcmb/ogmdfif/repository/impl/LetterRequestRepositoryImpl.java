package tr.gov.tcmb.ogmdfif.repository.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import tr.gov.tcmb.ogmdfif.model.entity.LetterRequest;
import tr.gov.tcmb.ogmdfif.repository.LetterRequestRepositoryCustom;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class LetterRequestRepositoryImpl implements LetterRequestRepositoryCustom {

    private final EntityManager em;

    /**
     * PostgreSQL atomic claim:
     *  - selects READY rows (status_id=3) using FOR UPDATE SKIP LOCKED
     *  - updates them to PROCESSING (status_id=4)
     *  - returns updated rows (RETURNING r.*)
     */
    @Override
    @Transactional
    @SuppressWarnings("unchecked")
    public List<LetterRequest> claimReadyRequests(int limit, String updater, Short requestTypeId, String branchId) {

        String sql = """
            with picked as (
                select r.id
                  from ogmdfifodm.tletter_request r
                 where r.status_id = 3
                   and (r.next_attempt_at is null or r.next_attempt_at <= now())
                   and (:requestTypeId is null or r.request_type_id = :requestTypeId)
                   and (:branchId is null or r.branch_id = :branchId)
                 order by r.created_at asc
                 for update skip locked
                 limit :limit
            )
            update ogmdfifodm.tletter_request r
               set status_id = 4,
                   processing_started_at = coalesce(r.processing_started_at, now()),
                   updated_at = now(),
                   updater = :updater
              from picked
             where r.id = picked.id
             returning r.*;
            """;

        Query q = em.createNativeQuery(sql, LetterRequest.class);
        q.setParameter("limit", limit);
        q.setParameter("updater", updater);
        q.setParameter("requestTypeId", requestTypeId);
        q.setParameter("branchId", branchId);

        return q.getResultList();
    }
}

package tr.gov.tcmb.ogmdfif.service.manual;

import lombok.Getter;

/**
 * Manuel talep akışında dedupe sonrası item kalmazsa fırlatılır.
 * UI katmanı bu exception'ı yakalayıp kullanıcıya userMessage gösterebilir.
 */
@Getter
public class NoItemsAfterDedupeException extends RuntimeException {

    private final String userMessage;

    public NoItemsAfterDedupeException(String userMessage, String technicalMessage) {
        super(technicalMessage);
        this.userMessage = userMessage;
    }
}

package tr.gov.tcmb.ogmdfif.service.processing;

import java.util.UUID;

@FunctionalInterface
public interface LetterRequestProcessor {
    void process(UUID requestId) throws Exception;
}

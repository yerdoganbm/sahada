package tr.gov.tcmb.ogmdfif.service.mail;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Şube yazışma maili çözümleyici.
 *
 * Tercih sırası:
 *  1) application.properties içinden mapping: branch.mail.map=34=a@x,06=b@y
 *  2) (Opsiyonel) projede varsa SubeKoduEnum gibi bir enum üzerinden reflection ile çek
 *  3) fallback boş
 */
@Component
public class BranchMailResolver {

    private final Map<String, String> map;

    public BranchMailResolver(@Value("${branch.mail.map:}") String csv) {
        this.map = parse(csv);
    }

    public Optional<String> resolve(String branchId) {
        if (branchId == null) return Optional.empty();
        String v = map.get(branchId);
        if (v != null && !v.isBlank()) return Optional.of(v);

        // Optional: reflection ile projedeki enum'dan çek
        // (compile-time dependency olmaması için reflection)
        try {
            Class<?> c = Class.forName("tr.gov.tcmb.ogmdfif.constant.SubeKoduEnum");
            // SubeKoduEnum.getById(String)
            Object enumVal = c.getMethod("getById", String.class).invoke(null, branchId);
            if (enumVal != null) {
                // getDfifYazismaEmailAdresi()
                Object mail = enumVal.getClass().getMethod("getDfifYazismaEmailAdresi").invoke(enumVal);
                if (mail != null && !String.valueOf(mail).isBlank()) {
                    return Optional.of(String.valueOf(mail));
                }
            }
        } catch (Exception ignore) {
            // ignore
        }

        return Optional.empty();
    }

    private static Map<String, String> parse(String csv) {
        Map<String, String> out = new HashMap<>();
        if (csv == null || csv.isBlank()) return out;
        String[] parts = csv.split(",");
        for (String p : parts) {
            String s = p.trim();
            if (s.isEmpty()) continue;
            int idx = s.indexOf('=');
            if (idx <= 0) continue;
            String k = s.substring(0, idx).trim();
            String v = s.substring(idx + 1).trim();
            if (!k.isEmpty() && !v.isEmpty()) out.put(k, v);
        }
        return out;
    }
}

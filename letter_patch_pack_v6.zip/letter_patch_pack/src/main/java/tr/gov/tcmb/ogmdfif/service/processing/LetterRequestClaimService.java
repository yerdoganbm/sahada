package tr.gov.tcmb.ogmdfif.service.processing;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tr.gov.tcmb.ogmdfif.model.entity.LetterRequest;
import tr.gov.tcmb.ogmdfif.repository.LetterRequestRepositoryCustom;

import java.util.List;

@Service
@RequiredArgsConstructor
public class LetterRequestClaimService {

    private final LetterRequestRepositoryCustom claimRepo;

    /**
     * Short transaction claim.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public List<LetterRequest> claim(int limit, String updater, Short requestTypeId, String branchId) {
        return claimRepo.claimReadyRequests(limit, updater, requestTypeId, branchId);
    }
}

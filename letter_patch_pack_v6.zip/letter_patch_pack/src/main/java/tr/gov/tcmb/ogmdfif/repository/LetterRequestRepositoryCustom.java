package tr.gov.tcmb.ogmdfif.repository;

import tr.gov.tcmb.ogmdfif.model.entity.LetterRequest;

import java.util.List;

/**
 * PostgreSQL atomic claim helpers.
 *
 * READY (3) -> PROCESSING (4)
 * Uses FOR UPDATE SKIP LOCKED so multiple workers can run safely.
 */
public interface LetterRequestRepositoryCustom {

    /**
     * Claim READY requests in a single atomic statement.
     *
     * @param limit         max number of requests to claim
     * @param updater       updater string to write into row (optional)
     * @param requestTypeId optional filter (null = all)
     * @param branchId      optional filter (null = all)
     */
    List<LetterRequest> claimReadyRequests(int limit, String updater, Short requestTypeId, String branchId);

    default List<LetterRequest> claimReadyRequests(int limit, String updater) {
        return claimReadyRequests(limit, updater, null, null);
    }
}

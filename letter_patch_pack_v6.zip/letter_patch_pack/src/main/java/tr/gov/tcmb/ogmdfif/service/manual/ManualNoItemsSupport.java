package tr.gov.tcmb.ogmdfif.service.manual;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.UUID;

/**
 * Dedupe sonrası item kalmadığında request'i NO_ITEMS'a çekmek ve kullanıcı mesajı üretmek için yardımcı.
 *
 * Varsayılan request status kodu: NO_ITEMS=10 (projendeki enum'a göre güncelle).
 */
@Service
@RequiredArgsConstructor
public class ManualNoItemsSupport {

    @PersistenceContext
    private EntityManager em;

    @Transactional
    public void markRequestNoItems(UUID requestId, String updater, String reason) {
        em.createNativeQuery("""
            update ogmdfifodm.tletter_request
               set status_id = 10,
                   last_error_code = 'NO_ITEMS_DEDUPE',
                   last_error_message = :reason,
                   updated_at = now(),
                   updater = :updater
             where id = :id
        """)
          .setParameter("reason", reason)
          .setParameter("updater", updater)
          .setParameter("id", requestId)
          .executeUpdate();
    }

    public String buildUserMessage(int skippedSucceeded, int skippedInPipeline) {
        // Kısa ve net: ekranda gösterilecek
        return "Bu ödeme mektubu için seçilen kriterlerde zaten işlem yapılmış/işleniyor olduğu için yeni talep üretilmedi. " +
                "(Gönderilmiş=" + skippedSucceeded + ", İşlemde=" + skippedInPipeline + ")";
    }
}

package tr.gov.tcmb.ogmdfif.service.mail;

import org.springframework.stereotype.Component;
import tr.gov.tcmb.ogmdfif.model.entity.LetterAttempt;
import tr.gov.tcmb.ogmdfif.model.entity.LetterItem;
import tr.gov.tcmb.ogmdfif.model.entity.LetterRequest;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class FailureMailComposer {

    public String compose(LocalDate day,
                          String branchId,
                          List<LetterRequest> requests,
                          List<LetterItem> allItems,
                          List<LetterAttempt> allAttempts) {

        Set<UUID> requestIds = requests.stream().map(LetterRequest::getId).collect(Collectors.toSet());

        List<LetterItem> items = allItems.stream()
                .filter(i -> requestIds.contains(i.getRequestId()))
                .collect(Collectors.toList());

        List<LetterAttempt> attempts = allAttempts.stream()
                .filter(a -> requestIds.contains(a.getRequestId()))
                .collect(Collectors.toList());

        Map<UUID, List<LetterItem>> itemsByReq = items.stream().collect(Collectors.groupingBy(LetterItem::getRequestId));
        Map<UUID, List<LetterAttempt>> attByReq = attempts.stream().collect(Collectors.groupingBy(LetterAttempt::getRequestId));

        StringBuilder sb = new StringBuilder(64_000);
        sb.append("<html><head><meta charset='UTF-8'>")
          .append("<style>")
          .append("body{font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#111}")
          .append("table{border-collapse:collapse;width:100%}")
          .append("th,td{border:1px solid #ddd;padding:6px;vertical-align:top}")
          .append("th{background:#f3f3f3}")
          .append(".muted{color:#666}")
          .append("</style></head><body>");

        sb.append("<h2>Otomatik Ödeme Mektubu - Başarısız Talepler</h2>")
          .append("<div class='muted'>Tarih: ").append(day)
          .append(" | Şube: ").append(escape(branchId))
          .append(" | Talep Sayısı: ").append(requests.size())
          .append("</div><br/>");

        // Summary table
        sb.append("<table><thead><tr>")
          .append("<th>RequestId</th><th>Status</th><th>Kas/Ödeme Aralığı</th><th>LastError</th><th>Item(Sent/Fail/All)</th>")
          .append("</tr></thead><tbody>");

        for (LetterRequest r : requests) {
            List<LetterItem> ri = itemsByReq.getOrDefault(r.getId(), List.of());
            long sent = ri.stream().filter(x -> Objects.equals(x.getStatusId(), (short) 6)).count();
            long fail = ri.stream().filter(x -> Objects.equals(x.getStatusId(), (short) 7)).count();

            sb.append("<tr>")
              .append("<td>").append(r.getId()).append("</td>")
              .append("<td>").append(r.getStatusId()).append("</td>")
              .append("<td>").append(escape(nvl(r.getFirstPaymentDate()))).append(" - ").append(escape(nvl(r.getLastPaymentDate()))).append("</td>")
              .append("<td>").append(escape(nvl(r.getLastErrorCode()))).append("<br/>")
              .append(escape(shorten(nvl(r.getLastErrorMessage()), 240))).append("</td>")
              .append("<td>").append(sent).append(" / ").append(fail).append(" / ").append(ri.size()).append("</td>")
              .append("</tr>");
        }
        sb.append("</tbody></table><br/>");

        // Details per request
        for (LetterRequest r : requests) {
            sb.append("<h3>Request: ").append(r.getId()).append("</h3>")
              .append("<div class='muted'>Status=").append(r.getStatusId())
              .append(" | Window=").append(escape(nvl(r.getFirstPaymentDate()))).append(" - ").append(escape(nvl(r.getLastPaymentDate())))
              .append(" | createdBy=").append(escape(nvl(r.getCreatedBy())))
              .append("</div><br/>");

            List<LetterItem> ri = itemsByReq.getOrDefault(r.getId(), List.of());
            if (ri.isEmpty()) {
                sb.append("<div class='muted'>Item bulunamadı.</div><br/>");
            } else {
                sb.append("<b>Items</b>")
                  .append("<table><thead><tr>")
                  .append("<th>ItemId</th><th>ReceiverKey</th><th>Status</th><th>Attempt</th><th>LastError</th>")
                  .append("</tr></thead><tbody>");

                for (LetterItem i : ri) {
                    sb.append("<tr>")
                      .append("<td>").append(i.getId()).append("</td>")
                      .append("<td>").append(escape(nvl(i.getReceiverKey()))).append("</td>")
                      .append("<td>").append(i.getStatusId()).append("</td>")
                      .append("<td>").append(escape(nvl(i.getAttemptCount()))).append("</td>")
                      .append("<td>").append(escape(nvl(i.getLastErrorCode()))).append("<br/>")
                      .append(escape(shorten(nvl(i.getLastErrorMessage()), 240))).append("</td>")
                      .append("</tr>");
                }
                sb.append("</tbody></table><br/>");
            }

            List<LetterAttempt> ra = attByReq.getOrDefault(r.getId(), List.of());
            if (!ra.isEmpty()) {
                sb.append("<b>Attempts (sondan başa)</b>")
                  .append("<table><thead><tr>")
                  .append("<th>CreatedAt</th><th>ItemId</th><th>Status</th><th>Error</th>")
                  .append("</tr></thead><tbody>");

                for (LetterAttempt a : ra) {
                    sb.append("<tr>")
                      .append("<td>").append(escape(nvl(a.getCreatedAt()))).append("</td>")
                      .append("<td>").append(escape(nvl(a.getItemId()))).append("</td>")
                      .append("<td>").append(escape(nvl(a.getStatusId()))).append("</td>")
                      .append("<td>").append(escape(nvl(a.getErrorCode()))).append("<br/>")
                      .append(escape(shorten(nvl(a.getErrorMessage()), 240))).append("</td>")
                      .append("</tr>");
                }
                sb.append("</tbody></table><br/>");
            }
        }

        sb.append("</body></html>");
        return sb.toString();
    }

    private static String nvl(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private static String shorten(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}

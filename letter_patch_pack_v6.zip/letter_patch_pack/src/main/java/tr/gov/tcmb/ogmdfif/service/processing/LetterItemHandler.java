package tr.gov.tcmb.ogmdfif.service.processing;

import tr.gov.tcmb.ogmdfif.model.entity.LetterItem;

/**
 * Projedeki mevcut PDF üret + mail gönder logic’ini buraya bağlayın.
 */
@FunctionalInterface
public interface LetterItemHandler {

    void handle(LetterItem item) throws Exception;
}

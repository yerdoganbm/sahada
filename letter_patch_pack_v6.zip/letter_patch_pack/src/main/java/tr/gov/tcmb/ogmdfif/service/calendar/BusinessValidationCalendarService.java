package tr.gov.tcmb.ogmdfif.service.calendar;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.gov.tcmb.ogmdfif.validation.BusinessValidation;

import java.time.LocalDate;

/**
 * Holiday tablosu olmadan iş günü hesabı.
 * Kaynak: mevcut BusinessValidation (revize edilip takvim kuralları burada tutulur).
 *
 * Kural: Cumartesi ve Pazar tatil, resmi tatiller (config) tatil.
 */
@Service
@RequiredArgsConstructor
public class BusinessValidationCalendarService {

    private final BusinessValidation businessValidation;

    public boolean shouldRunToday(LocalDate today) {
        return businessValidation.shouldRunToday(today);
    }

    public LocalDate previousBusinessDay(LocalDate today) {
        return businessValidation.previousBusinessDay(today);
    }
}

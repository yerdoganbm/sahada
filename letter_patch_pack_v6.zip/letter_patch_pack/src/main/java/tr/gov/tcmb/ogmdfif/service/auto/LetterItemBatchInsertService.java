package tr.gov.tcmb.ogmdfif.service.auto;

import java.util.Map;
import java.util.UUID;

/**
 * Bu interface’i projedeki mevcut item insert mekanizmanıza bağlayın.
 *
 * Amaç: request oluşturulduktan sonra receiver listesi için tletter_item batch insert.
 */
public interface LetterItemBatchInsertService {

    /**
     * @param requestId request id
     * @param receivers key=receiver_key (provizyonId), value=receiver_value (örn tckn/vkn)
     */
    int insertItems(UUID requestId, Map<String, String> receivers);
}

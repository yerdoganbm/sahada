package tr.gov.tcmb.ogmdfif.repository;

import tr.gov.tcmb.ogmdfif.model.entity.LetterItem;

import java.util.List;
import java.util.UUID;

/**
 * Item-level atomic claim helpers.
 *
 * READY (1) -> PROCESSING (4)
 * Uses FOR UPDATE SKIP LOCKED so multiple workers can process items of the same request safely.
 */
public interface LetterItemRepositoryCustom {

    /**
     * Claim READY items for a specific request.
     */
    List<LetterItem> claimReadyItemsForRequest(UUID requestId, int limit, String updater);

    /**
     * Claim READY items for requests that are currently PROCESSING.
     * Useful if you want to run a dedicated item-worker that does not load requests first.
     */
    List<LetterItem> claimReadyItemsForProcessingRequests(int limit,
                                                         String updater,
                                                         Short requestTypeId,
                                                         String branchId);
}

package tr.gov.tcmb.ogmdfif.repository.dao;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import tr.gov.tcmb.ogmdfif.model.entity.LetterItem;
import tr.gov.tcmb.ogmdfif.model.entity.LetterRequest;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

@Repository
@RequiredArgsConstructor
public class LetterMailQueryDao {

    private final EntityManager em;

    @Transactional(readOnly = true)
    @SuppressWarnings("unchecked")
    public List<LetterRequest> findAutoFailedRequests(OffsetDateTime start, OffsetDateTime end, List<Short> statusIds) {
        String sql = """
            select *
              from ogmdfifodm.tletter_request r
             where r.created_at >= :startDate
               and r.created_at <  :endDate
               and r.created_by = 'SYSTEM_AUTO_JOB'
               and r.status_id in (:statusIds)
             order by r.branch_id, r.created_at
            """;
        Query q = em.createNativeQuery(sql, LetterRequest.class);
        q.setParameter("startDate", start);
        q.setParameter("endDate", end);
        q.setParameter("statusIds", statusIds);
        return q.getResultList();
    }

    @Transactional(readOnly = true)
    @SuppressWarnings("unchecked")
    public List<LetterItem> findItemsByRequestIds(List<UUID> requestIds) {
        if (requestIds == null || requestIds.isEmpty()) return List.of();
        String sql = """
            select *
              from ogmdfifodm.tletter_item i
             where i.request_id in (:requestIds)
             order by i.request_id, i.created_at
            """;
        Query q = em.createNativeQuery(sql, LetterItem.class);
        q.setParameter("requestIds", requestIds);
        return q.getResultList();
    }
}

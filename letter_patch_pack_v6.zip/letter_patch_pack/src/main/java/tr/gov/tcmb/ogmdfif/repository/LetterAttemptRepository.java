package tr.gov.tcmb.ogmdfif.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tr.gov.tcmb.ogmdfif.model.entity.LetterAttempt;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface LetterAttemptRepository extends JpaRepository<LetterAttempt, UUID> {

    @Query(value = """
        select *
          from ogmdfifodm.tletter_attempt a
         where a.request_id = :requestId
         order by a.created_at desc
        """, nativeQuery = true)
    List<LetterAttempt> findByRequestIdOrderByCreatedDesc(@Param("requestId") UUID requestId);

    @Query(value = """
        select *
          from ogmdfifodm.tletter_attempt a
         where a.item_id = :itemId
         order by a.created_at desc
        """, nativeQuery = true)
    List<LetterAttempt> findByItemIdOrderByCreatedDesc(@Param("itemId") UUID itemId);

    @Query(value = """
        select *
          from ogmdfifodm.tletter_attempt a
         where a.request_id in (:requestIds)
         order by a.request_id, a.item_id, a.created_at desc
        """, nativeQuery = true)
    List<LetterAttempt> findByRequestIds(@Param("requestIds") List<UUID> requestIds);

    @Query(value = """
        select *
          from ogmdfifodm.tletter_attempt a
         where a.created_at >= :startDate
           and a.created_at <  :endDate
           and a.status_id in (:statusIds)
         order by a.created_at desc
        """, nativeQuery = true)
    List<LetterAttempt> findAttemptsBetweenDatesWithStatuses(@Param("startDate") OffsetDateTime startDate,
                                                            @Param("endDate") OffsetDateTime endDate,
                                                            @Param("statusIds") List<Short> statusIds);
}

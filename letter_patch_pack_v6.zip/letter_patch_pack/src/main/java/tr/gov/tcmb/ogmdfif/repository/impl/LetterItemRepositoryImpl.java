package tr.gov.tcmb.ogmdfif.repository.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import tr.gov.tcmb.ogmdfif.model.entity.LetterItem;
import tr.gov.tcmb.ogmdfif.repository.LetterItemRepositoryCustom;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;
import java.util.UUID;

@Repository
@RequiredArgsConstructor
public class LetterItemRepositoryImpl implements LetterItemRepositoryCustom {

    private final EntityManager em;

    @Override
    @Transactional
    @SuppressWarnings("unchecked")
    public List<LetterItem> claimReadyItemsForRequest(UUID requestId, int limit, String updater) {

        String sql = """
            with picked as (
                select i.id
                  from ogmdfifodm.tletter_item i
                 where i.request_id = :requestId
                   and i.status_id = 1
                 order by i.created_at asc
                 for update skip locked
                 limit :limit
            )
            update ogmdfifodm.tletter_item i
               set status_id = 4,
                   updated_at = now(),
                   updater = :updater
              from picked
             where i.id = picked.id
             returning i.*;
            """;

        Query q = em.createNativeQuery(sql, LetterItem.class);
        q.setParameter("requestId", requestId);
        q.setParameter("limit", limit);
        q.setParameter("updater", updater);

        return q.getResultList();
    }

    @Override
    @Transactional
    @SuppressWarnings("unchecked")
    public List<LetterItem> claimReadyItemsForProcessingRequests(int limit,
                                                                String updater,
                                                                Short requestTypeId,
                                                                String branchId) {

        String sql = """
            with picked as (
                select i.id
                  from ogmdfifodm.tletter_item i
                  join ogmdfifodm.tletter_request r on r.id = i.request_id
                 where r.status_id = 4
                   and i.status_id = 1
                   and (:requestTypeId is null or r.request_type_id = :requestTypeId)
                   and (:branchId is null or r.branch_id = :branchId)
                 order by r.created_at asc, i.created_at asc
                 for update of i skip locked
                 limit :limit
            )
            update ogmdfifodm.tletter_item i
               set status_id = 4,
                   updated_at = now(),
                   updater = :updater
              from picked
             where i.id = picked.id
             returning i.*;
            """;

        Query q = em.createNativeQuery(sql, LetterItem.class);
        q.setParameter("limit", limit);
        q.setParameter("updater", updater);
        q.setParameter("requestTypeId", requestTypeId);
        q.setParameter("branchId", branchId);

        return q.getResultList();
    }
}

package tr.gov.tcmb.ogmdfif.schedular;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import tr.gov.tcmb.ogmdfif.service.auto.AutoOdemeMektubuTalepService;

@Slf4j
@Component("jobs_autoOdemeMektubuTalepOlusturmaJob")
@RequiredArgsConstructor
public class AutoOdemeMektubuTalepOlusturmaJob implements Runnable {

    private final AutoOdemeMektubuTalepService service;

    @Override
    public void run() {
        log.info("AUTO_ODEME_JOB: started");
        service.runOnce();
        log.info("AUTO_ODEME_JOB: finished");
    }
}

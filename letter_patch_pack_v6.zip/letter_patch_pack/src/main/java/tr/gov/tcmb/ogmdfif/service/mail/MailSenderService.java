package tr.gov.tcmb.ogmdfif.service.mail;

/**
 * Projede zaten bir mail servisi var.
 * Buradaki interface sadece patch paketinin derlenebilir kalması içindir.
 *
 * Mevcut mail servisinizle aynı imzayı kullanın veya adapter yazın.
 */
public interface MailSenderService {
    void sendHtml(String to, String subject, String htmlBody);
}

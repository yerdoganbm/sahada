package tr.gov.tcmb.ogmdfif.service.auto;

import lombok.RequiredArgsConstructor;
import lombok.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.*;

@Repository
@RequiredArgsConstructor
public class LetterDedupeDao {

    private final EntityManager em;

    /**
     * Kalıcı dedupe: aynı provizyon daha önce SENT olmuşsa skip.
     */
    @Transactional(readOnly = true)
    @SuppressWarnings("unchecked")
    public List<String> findSucceededReceiverKeys(short requestTypeId, String branchId, List<String> receiverKeys) {
        if (receiverKeys == null || receiverKeys.isEmpty()) return Collections.emptyList();

        String sql = """
            select distinct i.receiver_key
              from ogmdfifodm.tletter_item i
              join ogmdfifodm.tletter_request r on r.id = i.request_id
             where r.request_type_id = :requestTypeId
               and r.branch_id = :branchId
               and i.receiver_key in (:receiverKeys)
               and i.status_id = 6
            """;

        Query q = em.createNativeQuery(sql);
        q.setParameter("requestTypeId", requestTypeId);
        q.setParameter("branchId", branchId);
        q.setParameter("receiverKeys", receiverKeys);
        return q.getResultList();
    }

    /**
     * Geçici dedupe: başka bir request tarafından pipeline’a alınmışsa skip.
     * Pipeline request status varsayılanları:
     *  PENDING=1, READY=3, PROCESSING=4, PARTIAL_SENT=5, SENT=6
     */
    @Transactional(readOnly = true)
    @SuppressWarnings("unchecked")
    public List<String> findInPipelineReceiverKeys(short requestTypeId, String branchId, List<String> receiverKeys) {
        if (receiverKeys == null || receiverKeys.isEmpty()) return Collections.emptyList();

        String sql = """
            select distinct i.receiver_key
              from ogmdfifodm.tletter_item i
              join ogmdfifodm.tletter_request r on r.id = i.request_id
             where r.request_type_id = :requestTypeId
               and r.branch_id = :branchId
               and i.receiver_key in (:receiverKeys)
               and r.status_id in (1,3,4,5,6)
            """;

        Query q = em.createNativeQuery(sql);
        q.setParameter("requestTypeId", requestTypeId);
        q.setParameter("branchId", branchId);
        q.setParameter("receiverKeys", receiverKeys);
        return q.getResultList();
    }

    @Value
    public static class AutoRequestInfo {
        UUID id;
        short statusId;
        OffsetDateTime createdAt;
    }

    /**
     * scope_value ile otomatik request’i bulur.
     */
    @Transactional(readOnly = true)
    public Optional<AutoRequestInfo> findAutoRequestInfo(String scopeValue) {
        String sql = """
            select r.id, r.status_id, r.created_at
              from ogmdfifodm.tletter_request r
             where r.scope_value = :scopeValue
               and r.created_by = 'SYSTEM_AUTO_JOB'
             order by r.created_at desc
             limit 1
            """;

        @SuppressWarnings("unchecked")
        List<Object[]> rows = em.createNativeQuery(sql)
                .setParameter("scopeValue", scopeValue)
                .getResultList();

        if (rows == null || rows.isEmpty()) return Optional.empty();

        Object[] row = rows.get(0);
        UUID id = (UUID) row[0];
        Number st = (Number) row[1];
        OffsetDateTime createdAt = (OffsetDateTime) row[2];
        return Optional.of(new AutoRequestInfo(id, st.shortValue(), createdAt));
    }

    @Value
    public static class RequeueResult {
        boolean requestRequeued;
        int retryableItemsReset;     // FAILED -> READY (attemptCount < max)
        int failedItemsMaxAttempt;   // FAILED items that reached max attempt
    }

    /**
     * Requeue policy (smarter):
     * - Yalnızca FAILED/ALL_FAILED auto request için çalışır.
     * - Sadece retryable FAILED item’ları (attempt_count < maxAttemptCount) READY item’a çevirir.
     * - retryable item yoksa request’i READY'ye çekmez.
     *
     * Varsayılan kodlar (projene göre uyarlayabilirsin):
     *  request status: READY=3, FAILED=7, ALL_FAILED=9
     *  item status: READY=1, FAILED=7
     */
    @Transactional
    public RequeueResult requeueFailedAutoRequest(UUID requestId,
                                                  String updater,
                                                  int maxAttemptCount,
                                                  boolean sameDayOnly,
                                                  OffsetDateTime dayStart,
                                                  OffsetDateTime dayEnd) {

        // (Opsiyonel) same-day guard DB seviyesinde de uygula:
        String createdAtFilter = sameDayOnly ? " and r.created_at >= :dayStart and r.created_at < :dayEnd" : "";

        // 0) max attempt’e ulaşmış FAILED item sayısı (mail/metric için)
        String maxCountSql = """
            select count(*)
              from ogmdfifodm.tletter_item i
             where i.request_id = :requestId
               and i.status_id = 7
               and coalesce(i.attempt_count, 0) >= :maxAttempt
        """;
        Number maxCnt = (Number) em.createNativeQuery(maxCountSql)
                .setParameter("requestId", requestId)
                .setParameter("maxAttempt", maxAttemptCount)
                .getSingleResult();

        // 1) Retryable FAILED item’ları READY’ye çek
        String itemSql = """
            update ogmdfifodm.tletter_item
               set status_id = 1,
                   updated_at = now(),
                   updater = :updater
             where request_id = :requestId
               and status_id = 7
               and coalesce(attempt_count, 0) < :maxAttempt
        """;
        int reset = em.createNativeQuery(itemSql)
                .setParameter("updater", updater)
                .setParameter("requestId", requestId)
                .setParameter("maxAttempt", maxAttemptCount)
                .executeUpdate();

        // 2) Request’i READY’ye çek (yalnızca retryable item varsa)
        int req = 0;
        if (reset > 0) {
            String reqSql = """
                update ogmdfifodm.tletter_request r
                   set status_id = 3,
                       next_attempt_at = now(),
                       updated_at = now(),
                       updater = :updater
                 where r.id = :requestId
                   and r.created_by = 'SYSTEM_AUTO_JOB'
                   and r.status_id in (7, 9)
            """ + createdAtFilter;

            Query q = em.createNativeQuery(reqSql)
                    .setParameter("updater", updater)
                    .setParameter("requestId", requestId);

            if (sameDayOnly) {
                q.setParameter("dayStart", dayStart);
                q.setParameter("dayEnd", dayEnd);
            }
            req = q.executeUpdate();
        }

        return new RequeueResult(req > 0, reset, maxCnt == null ? 0 : maxCnt.intValue());
    }

    /**
     * AUTO job catch-up için: scope_value içindeki KAS=YYYY-MM-DD değerlerinden en büyüğünü döner.
     *
     * scope_value ör: AUTO_ODEME|KAS=2026-03-17|BRANCH=34|PART=1
     */
    @Transactional(readOnly = true)
    /**
 * Otomatik job için daha güvenilir "son işlenen kas tarihi" tespiti.
 *
 * Not: Burada sadece "tamamlandı" sayılacak request status'lerini dikkate alıyoruz.
 * Önerilen include set:
 *  - SENT (6)
 *  - PARTIAL_SENT (5)
 *  - NO_ITEMS (10)
 *  - VALIDATION_FAIL (2)  (tekrar üretip spam olmaması için)
 *
 * FAILED / ALL_FAILED gibi durumlar dahil edilmez; böylece catch-up tekrar deneme şansı olur.
 *
 * scope_value ör: AUTO_ODEME|KAS=2026-03-17|BRANCH=34|PART=1
 */
@Transactional(readOnly = true)
public LocalDate findMaxAutoKasDate(String branchId,
                                    String createdBy,
                                    short requestTypeId,
                                    List<Short> includeStatusIds) {

    String sql = """
        select max( (substring(r.scope_value from 'KAS=([0-9]{4}-[0-9]{2}-[0-9]{2})'))::date )
          from ogmdfifodm.tletter_request r
         where r.created_by = :createdBy
           and r.branch_id = :branchId
           and r.request_type_id = :requestTypeId
           and r.scope_value like 'AUTO_ODEME|KAS=%'
           and ( :includeStatusIds is null or r.status_id in (:includeStatusIds) )
        """;

    Query q = em.createNativeQuery(sql);
    q.setParameter("createdBy", createdBy);
    q.setParameter("branchId", branchId);
    q.setParameter("requestTypeId", requestTypeId);
    q.setParameter("includeStatusIds", includeStatusIds);

    Object o = q.getSingleResult();
    return o == null ? null : ((java.sql.Date) o).toLocalDate();
}

}

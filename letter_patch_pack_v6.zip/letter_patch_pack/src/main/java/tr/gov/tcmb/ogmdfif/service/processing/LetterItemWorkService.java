package tr.gov.tcmb.ogmdfif.service.processing;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tr.gov.tcmb.ogmdfif.model.entity.LetterItem;
import tr.gov.tcmb.ogmdfif.repository.LetterItemRepositoryCustom;

import java.util.List;
import java.util.UUID;

/**
 * Item-level worker (SKIP LOCKED ile).
 *
 * Aynı request üzerinde birden fazla worker paralel çalıştırılabilir:
 *  - Her worker claimReadyItemsForRequest çağırır
 *  - Row-level lock sayesinde birbirlerinin item’ını kapmaz
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class LetterItemWorkService {

    private final LetterItemRepositoryCustom itemClaimRepo;

    /**
     * Items are claimed (READY->PROCESSING) in small batches.
     * Handler içinde mevcut PDF/mail gönderme çağrılarınızı kullanın.
     */
    public void processRequestItems(UUID requestId,
                                    int batchSize,
                                    String workerName,
                                    LetterItemHandler handler) {

        while (true) {
            List<LetterItem> batch = claimBatch(requestId, batchSize, workerName);
            if (batch.isEmpty()) break;

            for (LetterItem item : batch) {
                try {
                    handler.handle(item);
                    // Not: item status update (SENT/FAILED) projedeki mevcut servisinizde yapılıyorsa burada yapmayın.
                } catch (Exception ex) {
                    log.error("ITEM_WORK: requestId={} itemId={} failed", requestId, item.getId(), ex);
                    // Not: item status update (FAILED + attempt) yine mevcut mekanizmaya bağlanmalı.
                }
            }
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    protected List<LetterItem> claimBatch(UUID requestId, int batchSize, String workerName) {
        return itemClaimRepo.claimReadyItemsForRequest(requestId, batchSize, workerName);
    }
}

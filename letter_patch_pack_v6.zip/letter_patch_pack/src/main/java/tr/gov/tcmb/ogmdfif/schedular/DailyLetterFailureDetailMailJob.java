package tr.gov.tcmb.ogmdfif.schedular;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import tr.gov.tcmb.ogmdfif.model.entity.LetterAttempt;
import tr.gov.tcmb.ogmdfif.model.entity.LetterItem;
import tr.gov.tcmb.ogmdfif.model.entity.LetterRequest;
import tr.gov.tcmb.ogmdfif.repository.LetterAttemptRepository;
import tr.gov.tcmb.ogmdfif.repository.dao.LetterMailQueryDao;
import tr.gov.tcmb.ogmdfif.service.mail.BranchMailResolver;
import tr.gov.tcmb.ogmdfif.service.mail.FailureMailComposer;
import tr.gov.tcmb.ogmdfif.service.mail.MailSenderService;

import java.time.*;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component("jobs_dailyLetterFailureDetailMailJob")
@RequiredArgsConstructor
public class DailyLetterFailureDetailMailJob implements Runnable {

    private final LetterMailQueryDao mailQueryDao;
    private final LetterAttemptRepository letterAttemptRepository;
    private final FailureMailComposer composer;
    private final MailSenderService mailSenderService;
    private final BranchMailResolver branchMailResolver;

    @Override
    public void run() {
        runInternal();
    }

    @Transactional(readOnly = true)
    public void runInternal() {
        ZoneId zone = ZoneId.of("Europe/Istanbul");
        LocalDate today = LocalDate.now(zone);

        OffsetDateTime start = today.atStartOfDay(zone).toOffsetDateTime();
        OffsetDateTime end = today.plusDays(1).atStartOfDay(zone).toOffsetDateTime();

        // Status kodlarını sizin enum’larınıza göre güncelleyin.
        List<Short> failedStatusIds = List.of(
                (short) 2,  // VALIDATION_FAIL
                (short) 7,  // FAILED
                (short) 9,  // ALL_FAILED
                (short) 10  // NO_ITEMS
        );

        List<LetterRequest> failedReqs = mailQueryDao.findAutoFailedRequests(start, end, failedStatusIds);
        if (failedReqs.isEmpty()) {
            log.info("DAILY_FAIL_MAIL: no failed auto requests for {}", today);
            return;
        }

        List<UUID> requestIds = failedReqs.stream().map(LetterRequest::getId).collect(Collectors.toList());
        List<LetterItem> items = mailQueryDao.findItemsByRequestIds(requestIds);
        List<LetterAttempt> attempts = letterAttemptRepository.findByRequestIds(requestIds);

        Map<String, List<LetterRequest>> byBranch = failedReqs.stream()
                .collect(Collectors.groupingBy(LetterRequest::getBranchId));

        for (Map.Entry<String, List<LetterRequest>> e : byBranch.entrySet()) {
            String branchId = e.getKey();
            List<LetterRequest> branchReqs = e.getValue();

            String to = branchMailResolver.resolve(branchId).orElse("ogmfon@tcmb.gov.tr");
            String subject = "OGMDFIF - Otomatik Ödeme Mektubu Başarısız Talepler (" + today + ") - Şube " + branchId;

            String html = composer.compose(today, branchId, branchReqs, items, attempts);
            mailSenderService.sendHtml(to, subject, html);

            log.info("DAILY_FAIL_MAIL: sent branch={} to={} reqCount={} itemCount={} attemptCount={}",
                    branchId, to, branchReqs.size(),
                    items.stream().filter(it -> branchReqs.stream().map(r -> r.getId()).anyMatch(id -> Objects.equals(id, it.getRequestId()))).count(),
                    attempts.size());
        }
    }
}

package tr.gov.tcmb.ogmdfif.service.auto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class AutoJobRunStats {
    String branchId;
    String kasDate;

    int fetchedCandidateCount;
    int uniqueReceiverCount;

    int skippedSucceededCount;
    int skippedInPipelineCount;

    int willInsertCount;

    int createdRequestCount;
    int insertedItemCount;

    // Requeue metrics (same-scope existing FAILED/ALL_FAILED requests)
    int requeuedRequestCount;
    int requeuedItemResetCount;
    int requeueSkippedNotSameDayCount;
    int requeueSkippedMaxAttemptCount;
    int requeueNoRetryableItemsCount;
}

package tr.gov.tcmb.ogmdfif.schedular;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import tr.gov.tcmb.ogmdfif.model.entity.LetterRequest;
import tr.gov.tcmb.ogmdfif.service.processing.LetterRequestClaimService;
import tr.gov.tcmb.ogmdfif.service.processing.LetterRequestProcessor;

import java.util.List;

/**
 * Örnek: jobs_letterProcessingJob için SKIP LOCKED + atomic claim versiyonu.
 *
 * Entegrasyon:
 *  - mevcut process logic’inizi LetterRequestProcessor implementasyonu olarak bağlayın.
 */
@Slf4j
@Component("jobs_letterProcessingJobV2")
@RequiredArgsConstructor
public class LetterProcessingJobV2 implements Runnable {

    private final LetterRequestClaimService claimService;
    private final LetterRequestProcessor requestProcessor;

    @Value("${letter.processing.claim.limit:20}")
    private int claimLimit;

    @Value("${letter.processing.filter.requestTypeId:}")
    private String requestTypeIdStr;

    @Value("${letter.processing.filter.branchId:}")
    private String branchId;

    @Override
    public void run() {
        Short requestTypeId = null;
        if (requestTypeIdStr != null && !requestTypeIdStr.isBlank()) {
            requestTypeId = Short.valueOf(requestTypeIdStr.trim());
        }
        String branch = (branchId != null && !branchId.isBlank()) ? branchId.trim() : null;

        List<LetterRequest> claimed = claimService.claim(claimLimit, "jobs_letterProcessingJob", requestTypeId, branch);
        if (claimed.isEmpty()) {
            log.debug("LETTER_PROCESSING_V2: no READY request claimed");
            return;
        }

        log.info("LETTER_PROCESSING_V2: claimed {} request(s)", claimed.size());

        for (LetterRequest req : claimed) {
            try {
                requestProcessor.process(req.getId());
            } catch (Exception ex) {
                log.error("LETTER_PROCESSING_V2: requestId={} failed", req.getId(), ex);
            }
        }
    }
}
